package com.example.jotaz.bdusinglist;

import android.content.ContentValues;
import android.content.SharedPreferences;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.example.jotaz.bdusinglist.Helpers.SuperMarketBDHelper;

public class RegistActivity extends AppCompatActivity {

    EditText txtNombre, txtLugar, txtObservacion, txtRating;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_regist);

        InicializarControles();
    }

    private void InicializarControles(){

        txtNombre = (EditText)findViewById(R.id.txtNombreR);
        txtLugar = (EditText)findViewById(R.id.txtLugarR);
        txtObservacion = (EditText)findViewById(R.id.txtObservacionR);
        txtRating = (EditText)findViewById(R.id.txtRatingR);

    }

    public void GuardarDatos(View v)
    {
        SuperMarketBDHelper smDB = new SuperMarketBDHelper(this,"Supermercados",null,1);

        SQLiteDatabase db = smDB.getWritableDatabase();

        if (db != null)
        {

            try{

                ContentValues content = new ContentValues();
                content.put("nombre", txtNombre.getText().toString());
                content.put("lugar", txtLugar.getText().toString());
                content.put("observacion", txtObservacion.getText().toString());
                content.put("rating", Integer.parseInt(txtRating.getText().toString()));

                db.insert("supermercados", null, content);
                Toast.makeText(this,"Todo bien, se inserto, fijate en el list ", Toast.LENGTH_LONG).show();
            }
            catch (Exception e)
            {
                Toast.makeText(this,"Error -> " + e.getMessage().toString(), Toast.LENGTH_LONG).show();
            }
            finally {
                db.close();
            }
        }
    }
}

package com.example.jotaz.bdusinglist.Adapterss;

import android.content.Context;
import android.support.annotation.NonNull;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import com.example.jotaz.bdusinglist.Entidades.Supermercados;
import com.example.jotaz.bdusinglist.R;

import java.util.ArrayList;
import java.util.List;

public class SuperMarketAdapters extends ArrayAdapter<Supermercados>
{

    private  List<Supermercados> opciones = new ArrayList<>();

    public SuperMarketAdapters(Context context, List<Supermercados> datos){
        super(context, R.layout.lst_supermercados, datos);

        opciones= datos;
    }

    public View getView(int position, View convertView, ViewGroup parent) {
        LayoutInflater inflater = LayoutInflater.from(getContext());
        View item = inflater.inflate(R.layout.lst_supermercados, null);

        TextView lblNombre = (TextView)item.findViewById(R.id.txtNombre);
        lblNombre.setText(opciones.get(position).getNombre());

        TextView lblLugar = (TextView)item.findViewById(R.id.txtLugar);
        lblLugar.setText(opciones.get(position).getLugar());

        TextView lblObservacion = (TextView)item.findViewById(R.id.txtObservacion);
        lblObservacion.setText(opciones.get(position).getObservacion());

        TextView lblRating = (TextView)item.findViewById(R.id.txtRating);
        lblRating.setText(Integer.toString(opciones.get(position).getRating()));

        return(item);
    }
}

package com.example.jotaz.bdusinglist.Helpers;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class SuperMarketBDHelper extends SQLiteOpenHelper {

    String queryCreate = "CREATE TABLE supermercados(nombre TEXT, lugar TEXT, observacion TEXT, rating INTEGER)";

    public SuperMarketBDHelper(Context context, String nombre, SQLiteDatabase.CursorFactory factory, int version)
    {
        super(context, nombre, factory, version);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(queryCreate);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }
}

package com.example.jotaz.bdusinglist;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;
import android.widget.Toast;

import com.example.jotaz.bdusinglist.Adapterss.SuperMarketAdapters;
import com.example.jotaz.bdusinglist.Entidades.Supermercados;
import com.example.jotaz.bdusinglist.Helpers.SuperMarketBDHelper;

import java.util.ArrayList;
import java.util.List;

public class ListActivity extends AppCompatActivity {

    ListView lstSupermercados;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        lstSupermercados = (ListView)findViewById(R.id.lstSupermercados);

        this.LoadListViewTemplate();
    }

    public void AbrirGuardador(View view){

        Intent i = new Intent(this, RegistActivity.class);
        startActivity(i);
    }

    private void LoadListViewTemplate()
    {
        List<Supermercados> opciones = this.ObtenerDatos();

        SuperMarketAdapters adapter = new SuperMarketAdapters(this, opciones);

        lstSupermercados.setAdapter(adapter);
    }

    private List<Supermercados> ObtenerDatos(){

        List<Supermercados> lista = new ArrayList<Supermercados>();

        try{
            SuperMarketBDHelper smDB = new SuperMarketBDHelper(this,"Supermercados",null,1);

            SQLiteDatabase db = smDB.getReadableDatabase();

            if (db!= null)
            {
                String[] campos = new String[]{"nombre","lugar","observacion","rating"};
                Cursor cursor = db.query("supermercados", campos, null, null, null, null
                        , null);

                if (cursor.moveToFirst()){
                    do {
                        Supermercados sm = new Supermercados();

                        sm.setNombre(cursor.getString(0));
                        sm.setLugar(cursor.getString(1));
                        sm.setObservacion(cursor.getString(2));
                        sm.setRating(cursor.getInt(3));

                        lista.add(sm);

                    }while (cursor.moveToNext());
                }
            }
        }
        catch (Exception e){
            Toast.makeText(this,"Error -> " + e.getMessage().toString(), Toast.LENGTH_LONG).show();
        }

        return lista;
    }

}
